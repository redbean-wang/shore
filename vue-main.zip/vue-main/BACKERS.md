<h1 align="center">Sponsors &amp; Backers</h1>

Vue.js is an MIT-licensed open source project with its ongoing development made possible entirely by the support of the awesome sponsors and backers listed in this file. If you'd like to join them, please consider [ sponsor Vue's development](https://vuejs.org/sponsor/).

<p align="center">
  <a target="_blank" href="https://sponsors.vuejs.org/backers.svg">
    <img alt="sponsors" src="https://sponsors.vuejs.org/backers.svg">
  </a>
</p>
