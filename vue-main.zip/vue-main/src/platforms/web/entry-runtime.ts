import Vue from './runtime/index'
import * as vca from 'vca/index'
import { extend } from 'shared/util'

extend(Vue, vca)

export default Vue
