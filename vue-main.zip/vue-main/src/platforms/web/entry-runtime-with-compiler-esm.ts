import Vue from './runtime-with-compiler'

export default Vue

export * from 'vca/index'
